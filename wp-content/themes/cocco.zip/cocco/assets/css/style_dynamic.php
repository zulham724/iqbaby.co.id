<?php

do_action('cocco_mikado_action_style_dynamic');