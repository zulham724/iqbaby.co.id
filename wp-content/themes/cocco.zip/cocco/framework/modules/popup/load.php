<?php
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/popup/functions.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/popup/admin/options-map/popup-map.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/popup/template-hooks.php';