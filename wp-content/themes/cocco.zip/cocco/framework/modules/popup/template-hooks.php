<?php
//Get popup HTML
add_action('cocco_mikado_action_before_page_header', 'cocco_mikado_get_popup');