<?php

if ( cocco_mikado_is_wpml_installed() ) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/wpml/wpml-functions.php';
}