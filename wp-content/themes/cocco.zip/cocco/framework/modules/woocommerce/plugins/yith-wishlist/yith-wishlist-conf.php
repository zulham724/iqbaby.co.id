<?php

/*************** YITH WISHLIST FILTERS - begin ***************/

//Change yith wishlist button position on single product page

//Add yith wishlist button
add_action( 'cocco_mikado_action_woo_quickview_wishlist_holder', 'cocco_mikado_woocommerce_wishlist_shortcode', 2 );

//Remove quick view button from wishlist
remove_all_actions('yith_wcwl_table_after_product_name');


/*************** YITH WISHLIST FILTERS - end ***************/

