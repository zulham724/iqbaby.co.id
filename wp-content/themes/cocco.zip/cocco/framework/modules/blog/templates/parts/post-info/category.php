<div class="mkdf-post-info-category">
    <span class="icon_ribbon_alt"></span>
    <?php the_category(', '); ?>
</div>