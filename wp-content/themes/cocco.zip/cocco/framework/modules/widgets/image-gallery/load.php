<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/image-gallery/functions.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/image-gallery/image-gallery.php';